create unique index PRIMARY_KEY_8
    on TASK_GROUPS (ID);

